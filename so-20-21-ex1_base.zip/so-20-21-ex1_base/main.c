#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>
#include <ctype.h>
#include "fs/operations.h"

#define MAX_COMMANDS 150000
#define MAX_INPUT_SIZE 100

int numberThreads = 0;
struct timeval tvalBefore;

char inputCommands[MAX_COMMANDS][MAX_INPUT_SIZE];
int numberCommands = 0;
int headQueue = 0;

char strat[256];

pthread_mutex_t lock;
pthread_mutex_t global;
pthread_rwlock_t rwlock;

void count_time(){
    struct timeval tvalAfter;
    gettimeofday(&tvalAfter, NULL);
    
    long seconds = (tvalAfter.tv_sec - tvalBefore.tv_sec);
    long micros = ((seconds * 1000000) + tvalAfter.tv_usec)-(tvalBefore.tv_usec);

    printf("TecnicoFS completed in %ld.%.4ld seconds.\n",seconds, micros);
    }

int insertCommand(char* data) {
    if(numberCommands != MAX_COMMANDS) {
        strcpy(inputCommands[numberCommands++], data);
        return 1;
    }
    return 0;
}

char* removeCommand() {
    /*mutex*/
    pthread_mutex_lock(&global);
    if(numberCommands > 0){
        numberCommands--;
        pthread_mutex_unlock(&global);
        return inputCommands[headQueue++];  
    }
    return NULL;
    

}

void errorParse(){
    fprintf(stderr, "Error: command invalid\n");
    exit(EXIT_FAILURE);
}

void processInput(char* filename){
    char line[MAX_INPUT_SIZE];


    /* break loop with ^Z or ^D */
    FILE *file = fopen(filename, "r");
    
    if(file == NULL){
        fprintf(stderr, "Error: Problem with input file\n");
        exit(EXIT_SUCCESS);
        return;
    }
    
    while (fgets(line, sizeof(line)/sizeof(char), file)) {
        char token, type;
        char name[MAX_INPUT_SIZE];

        int numTokens = sscanf(line, "%c %s %c", &token, name, &type);

        /* perform minimal validation */
        if (numTokens < 1) {
            continue;
        }
        switch (token) {
            case 'c':
                if(numTokens != 3)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'l':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'd':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case '#':
                break;
            
            default: { /* error */
                errorParse();
            }
        }
    }
    fclose(file);
}

void applyCommands(){
        if(strcmp(strat,"mutex")==0)pthread_mutex_lock(&lock);
        if(strcmp(strat,"rwlock")==0)pthread_rwlock_wrlock(&rwlock);
        while (numberCommands > 0){
            const char* command = removeCommand();
            if (command == NULL){
                pthread_mutex_unlock(&global);
                continue;
            }
            char token, type;
            char name[MAX_INPUT_SIZE];
            int numTokens = sscanf(command, "%c %s %c", &token, name, &type);
            if (numTokens < 2) {
                fprintf(stderr, "Error: invalid command in Queue\n");
                exit(EXIT_FAILURE);
            }

            int searchResult;
            switch (token) {
                case 'c':
                    switch (type) {
                        case 'f':
                            if(strcmp(strat,"mutex")==0){
                                
                                fprintf(stderr,"Create file: %s\n", name);
                                create(name, T_FILE);
                                pthread_mutex_unlock(&lock);
                                break;
                            }
                            if(strcmp(strat,"nosync")==0){
                                fprintf(stderr,"Create file: %s\n", name);
                                create(name, T_FILE);
                                break;
                            }
                            if(strcmp(strat,"rwlock")==0){
                                
                                fprintf(stderr,"Create file: %s\n", name);
                                create(name, T_FILE);
                                pthread_rwlock_unlock(&rwlock);
                                break;
                            }

                        case 'd':
                            if(strcmp(strat,"mutex")==0){
                                
                                fprintf(stderr,"Create directory: %s\n", name);
                                create(name, T_DIRECTORY);
                                pthread_mutex_unlock(&lock);
                                break;
                            }
                            if(strcmp(strat,"nosync")==0){
                                fprintf(stderr,"Create directory: %s\n", name);
                                create(name, T_DIRECTORY);
                                break;
                            }
                            if(strcmp(strat,"rwlock")==0){
                                
                                fprintf(stderr,"Create directory: %s\n", name);
                                create(name, T_DIRECTORY);
                                pthread_rwlock_unlock(&rwlock);
                                 break;
                            }
                        default:
                            if(strcmp(strat,"mutex")==0){
                                
                                fprintf(stderr, "Error: invalid node type\n");
                                pthread_mutex_unlock(&lock);
                                exit(EXIT_FAILURE);
                            }
                            if(strcmp(strat,"nosync")==0){
                                fprintf(stderr, "Error: invalid node type\n");
                                exit(EXIT_FAILURE);
                            }
                            if(strcmp(strat,"rwlock")==0){
                                
                                fprintf(stderr, "Error: invalid node type\n");
                                pthread_rwlock_unlock(&rwlock);
                                exit(EXIT_FAILURE);
                            }
                    }
                    break;
                case 'l': 
                    if(strcmp(strat,"mutex")==0){    
                        
                        searchResult = lookup(name);
                        if (searchResult >= 0)
                            fprintf(stderr,"Search: %s found\n", name);
                        else
                            fprintf(stderr,"Search: %s not found\n", name);
                    pthread_mutex_unlock(&lock);
                    break;
                    }
                    if(strcmp(strat,"nosync")==0){
                        searchResult = lookup(name);
                        if (searchResult >= 0)
                            fprintf(stderr,"Search: %s found\n", name);
                        else
                            fprintf(stderr,"Search: %s not found\n", name);
                    break;
                    }
                    if(strcmp(strat,"rwlock")==0){
                        
                        searchResult = lookup(name);
                        if (searchResult >= 0)
                            fprintf(stderr,"Search: %s found\n", name);
                        else
                            fprintf(stderr,"Search: %s not found\n", name);
                    pthread_rwlock_unlock(&rwlock);
                    break;
                    }

                case 'd':
                    if(strcmp(strat,"mutex")==0){
                        fprintf(stderr,"Delete: %s\n", name);
                        delete(name);
                        pthread_mutex_unlock(&lock);
                        break;
                    }
                    if(strcmp(strat,"nosync")==0){
                        fprintf(stderr,"Delete: %s\n", name);
                        delete(name);
                        break;
                    }
                    if(strcmp(strat,"rwlock")==0){
                        
                        fprintf(stderr,"Delete: %s\n", name);
                        delete(name);
                        pthread_rwlock_unlock(&rwlock);
                        break;
                    }
                default: { /* error */
                    if(strcmp(strat,"mutex")==0){
                        
                        fprintf(stderr, "Error: command to apply\n");
                        pthread_mutex_unlock(&lock);
                        exit(EXIT_FAILURE);
                    }
                    if(strcmp(strat,"nosync")==0){
                        fprintf(stderr, "Error: command to apply\n");
                        exit(EXIT_FAILURE);
                    }
                    if(strcmp(strat,"rwlock")==0){
                        
                        fprintf(stderr, "Error: command to apply\n");
                        pthread_rwlock_unlock(&rwlock);
                        exit(EXIT_FAILURE);
                    }
                }
            }
        }
        if(strcmp(strat,"mutex")==0)pthread_mutex_unlock(&lock);
        if(strcmp(strat,"rwlock")==0)pthread_rwlock_unlock(&rwlock);
    }

void checkinput(int argc,char* argv){
    if(argc != 5){
        fprintf(stderr, "Error: Number of arguments is incorrect\n");
        count_time();
        exit(EXIT_SUCCESS);
    }
    if(numberThreads < 1){
        fprintf(stderr, "Error: Amount of threads is incorrect\n");
        count_time();
        exit(EXIT_SUCCESS);
    }

   if((strcmp(argv,"nosync")==0) && (numberThreads != 1)){
        fprintf(stderr, "Error: Number of threads doesnt match synchstrategy\n");
        count_time();
        exit(EXIT_SUCCESS);
    }
}

void processSyncStrategy(char* argv){
    int err;
    /*thread variables*/
    pthread_t tid[numberThreads];
    if((strcmp(argv,"mutex")==0)){
            /*starts mutex*/
            if (pthread_mutex_init(&lock, NULL) != 0){
                printf("\n mutex init failed\n");
                return;
            }
            /*creates threads*/
            for(int i=0; i < numberThreads;i++){
                 err = pthread_create(&(tid[i]), NULL, applyCommands, NULL);
                if (err != 0)
                    perror("Can't create thread");
            }
            /*joins/ends threads*/
            for(int i=0; i < numberThreads;i++){
                 if(pthread_join(tid[i], NULL)){
                    perror("Can't join thread");
                 }
            }   
            /*ends mutex*/
            pthread_mutex_destroy(&lock);
            return;
    }
    if((strcmp(argv,"rwlock")==0)){
            /*starts mutex*/
            if (pthread_rwlock_init(&rwlock, NULL) != 0){
                printf("rwlock init failed\n");
                return;
            }
            /*creates threads*/
            for(int i=0; i < numberThreads;i++){
                 err = pthread_create(&(tid[i]), NULL, applyCommands, NULL);
                if (err != 0)
                    perror("Can't create thread");
            }
            /*joins/ends threads*/
            for(int i=0; i < numberThreads;i++){
                 if(pthread_join(tid[i], NULL)){
                    perror("Can't join thread");
                 }
            }   
            /*ends mutex*/
            pthread_rwlock_destroy(&rwlock);
            return;
    }
    if((strcmp(argv,"nosync")==0)){
        applyCommands();
        return;
    }
}

int main(int argc, char* argv[]) {
    gettimeofday(&tvalBefore, NULL);
    
    numberThreads = atoi(argv[3]);
    if (pthread_mutex_init(&global, NULL) != 0){
        printf("\n mutex init failed\n");
        count_time();
        exit(EXIT_SUCCESS);
    }
    /*thread variables*/
    /*checks if input is correct*/
    strcpy(strat,argv[4]);
    checkinput(argc,argv[4]);

    /* init filesystem */
    init_fs();
    
    /* process input */
    processInput(argv[1]);  
    
    /* process strategy*/
    processSyncStrategy(argv[4]);
    
    /* prints tree */
    print_tecnicofs_tree(argv[2]);
    
    /* release allocated memory */
    pthread_mutex_destroy(&global);
    destroy_fs();
    count_time();
    exit(EXIT_SUCCESS);
}
